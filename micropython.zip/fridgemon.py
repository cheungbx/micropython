
import network
import time
import dht
from time import sleep
from machine import Pin
from dht import DHT22
from umqtt.robust import MQTTClient
import os
import sys

# callback function is called when scribed data is received from broker
def cb(topic, msg):
    global light_state
    print('Subscribe:  Received Data:  Topic = {}, Msg = {}\n'.format(topic, msg))
    if msg == b'ON':
        print ('LED on')
        led.off()
        light_state = 1
    elif msg == b'OFF':
        print ('LED off')
        led.on()
        light_state = 0

# WiFi connection information
WIFI_SSID = 'BILLYWIFI'
WIFI_PASSWORD = 'Xolmem13'

# turn off the WiFi Access Point
ap_if = network.WLAN(network.AP_IF)
ap_if.active(False)

# connect the device to the WiFi network
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(WIFI_SSID, WIFI_PASSWORD)

# wait until the device is connected to the WiFi network
MAX_ATTEMPTS = 20
attempt_count = 0
while not wifi.isconnected() and attempt_count < MAX_ATTEMPTS:
    attempt_count += 1
    time.sleep(1)

if attempt_count == MAX_ATTEMPTS:
    print('could not connect to the WiFi network')
    sys.exit()

# create a random MQTT clientID
random_num = int.from_bytes(os.urandom(3), 'little')
mqtt_client_id = bytes('client_'+str(random_num), 'utf-8')

# connect to Adafruit IO MQTT broker using unsecure TCP (port 1883)
#
# To use a secure connection (encrypted) with TLS:
#   set MQTTClient initializer parameter to "ssl=True"
#   Caveat: a secure connection uses about 9k bytes of the heap
#         (about 1/4 of the micropython heap on the ESP8266 platform)
ADAFRUIT_IO_URL = b'io.adafruit.com'
ADAFRUIT_USERNAME = b'cheungbx2'
ADAFRUIT_IO_KEY = b'0b62c232419448319c5469e2a26b8407'

client = MQTTClient(client_id=mqtt_client_id,
                    server=ADAFRUIT_IO_URL,
                    user=ADAFRUIT_USERNAME,
                    password=ADAFRUIT_IO_KEY,
                    ssl=False)



try:
    client.connect()
except Exception as e:
    print('could not connect to MQTT server {}{}'.format(type(e).__name__, e))
    sys.exit()

reported_err = 0
measure_period_ms = 60000
loop_delay_ms = 10
last_measure_ms = 0
debounce_start_ms = 0
debounce_period_ms = 20
last_button_state = 0
button_state = 0
light_state = 0
h = 72.5
h0 = 1.0
t = 28.3
t0 = 1.0

led = Pin(14, Pin.OUT)
button = Pin(12, Pin.IN, Pin.PULL_UP)
# publish humidity and temperature to Adafruit IO using MQTT
# subscribe to the light2 feed
#
# format of feed name:
#   "ADAFRUIT_USERNAME/feeds/ADAFRUIT_IO_FEEDNAME"

mqtt_feed_light = bytes('{:s}/feeds/lightsw'.format(ADAFRUIT_USERNAME), 'utf-8')
mqtt_feed_humidity = bytes('{:s}/feeds/humidity'.format(ADAFRUIT_USERNAME), 'utf-8')
mqtt_feed_temperature = bytes('{:s}/feeds/temperature'.format(ADAFRUIT_USERNAME), 'utf-8')
client.set_callback(cb)
client.subscribe(mqtt_feed_light)



# pin 3 = RX pin of ESP 8266 for DHT sensor
sensor = DHT22(Pin(13, Pin.IN, Pin.PULL_UP))

while True:
    # light switch
    button_value = button.value()
    if button_value != last_button_state :
        debounce_start_ms = time.ticks_ms()
    if abs(time.ticks_ms() - debounce_start_ms) >= debounce_period_ms :
        if button_value != button_state :
            button_state = button_value
            if button_state == 1 :
                if light_state == 0 :
                    led.off()
                    msg = "ON"
                    light_state = 1
                else :
                    led.on()
                    msg = "OFF"
                    light_state = 0

                print('Publish:  light {}'.format(msg))
                client.publish(mqtt_feed_light, msg, qos=0)
    last_button_state = button_value

    # Sensors
    try:
        if abs(time.ticks_ms() - last_measure_ms) >= measure_period_ms :
            try:
                sensor.measure()   # Poll sensor
                h = sensor.humidity()
                t = sensor.temperature()
            except OSError as err :
                print("Sensor error: {0}".format(err))
            msg = (b'{0:3.1f}'.format(h))
            if h != h0 :
                print('Publish:  humidity = {}'.format(h))
                client.publish(mqtt_feed_humidity, msg, qos=0)
                h0 = h

            msg = (b'{0:3.1f}'.format(t))
            if t != t0 :
                print('Publish:  temperature = {}'.format(t))
                client.publish(mqtt_feed_temperature, msg, qos=0)
                t0 = t
            last_measure_ms = time.ticks_ms()

        # Subscribe.  Non-blocking check for a new message.
        client.check_msg()

        time.sleep_ms(loop_delay_ms)

    except KeyboardInterrupt:
        print('Ctrl-C pressed...exiting')
        client.disconnect()
        sys.exit()
