from umachine import *
from .timer import *
from .pin import *

def unique_id():
    return b"upy-non-unique"
