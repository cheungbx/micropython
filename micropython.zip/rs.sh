rshell --buffer-size=30 -p /dev/cu.wchusbserial1440 

