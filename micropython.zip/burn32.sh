echo “This script erases ESP32 flash and burn micropython onto it. Before start, ESP 32 must be in boot loader mode, i.e. GPIO2 connected to ground”
# The ESP 32 should have a flash ram of at least 8M bit or 1M Byte.

echo “Press Enter to erase the ESP32 flash memory”

read -p "Enter to proceed. Control+C to quit" -r


# erase EEPROM of ESP 32
 
esptool.py --port /dev/tty.SLAB_USBtoUART erase_flash

echo “For some ESP32 generic modules, e.g. ESP-01S. You need to manually hard reset board now, e.g. turn off and turn on power. Then press Enter to continue to burn micropython to ESP32”
read -p "Enter to proceed. Control+C to quit" -r
sleep 2


# cd to directory where micropyhton binaries for ESP32 are stored.
cd ~/micropython

# burn the microphyton binary into ESP 32 EEPROM

# use this line for ESP32 
esptool.py --chip esp32 --port /dev/tty.SLAB_USBtoUART --baud 115200 write_flash -z 0x1000 esp32-20190529-v1.11.bin


echo “For some ESP32 generic modules, e.g. ESP-01S. You need to manually hard reset board now, e.g. turn off and turn on power. Then press Enter to connect to  ESP32 serial console for micro python”
read -p "Enter to proceed. Control+C to quit" -r
sleep 2

./rshell32.sh










