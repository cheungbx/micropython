import machine
from machine import Pin
pin = machine.Pin(2, machine.Pin.OUT)

import time
def toggle(p):  p.value(not p.value())
while True:
  toggle(pin)
  time.sleep_ms(500)


