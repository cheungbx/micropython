# echo “This script erases ESP8266 flash and burn micropython onto it. Before start, ESP 8266 must be in boot loader mode, i.e. GPIO2 connected to ground”
# The ESP 8266 should have a flash ram of at least 8M bit or 1M Byte.


# erase EEPROM of 8266
esptool.py --port /dev/tty.wchusbserial1430 erase_flash


# burn the microphyton binary into ESP 8266 EEPROM


esptool.py --port /dev/cu.wchusbserial1440 --baud 115200 write_flash --flash_size=detect 0 esp8266-20190529-v1.11.bin


