def east_asian_width(c):
    return 1


def normalize(form, unistr):
    return unistr
